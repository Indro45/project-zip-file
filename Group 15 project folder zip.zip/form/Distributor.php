<span style="font-family: verdana, geneva, sans-serif;"><!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <title>DISTRIBUTOR | By Code Info</title>
      <link rel="stylesheet" href="Distributor css file.css" />
      <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hedvig+Letters+Sans&family=Hedvig+Letters+Serif:opsz@12..24&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    </head>
    <body>
       
    
        <div id="container">
          <nav>  
            <a href="#" class="logo">
              <img src="niloy.jpg" alt="">
              <span class="nav-item"><b>Indronil Dey Niloy</b></span>
            </a>
            <a href="#">
              
              <span class="nav-item">Home</span>
            </a>
            <a href="">
              
              <span class="nav-item">Profile</span>
            </a>
            
            
           
            <a href="">
              
              <span class="nav-item">Settings</span>
            </a>
            <a href="">
              
              <span class="nav-item">Help</span>
            </a>
            <a href="">
                <span class="nav-item">logout</span>
              </a>
        </nav>
    
        <section class="main">
          <div class="main-top">
            <h1>DISTRIBUTOR'S DASHBOARD</h1>
            <i class="fas fa-user-cog"></i>
          </div>
          <div class="main-skills">
            <div class="card">
              <i class="fas fa-laptop-code"></i>
              <h3>OVERVIEW</h3>
              <p><ol type="1"><li>Total Sales</li>
                <input>Enter amount in $</input>
                <li>Profit Margin in $</li>
                <input>Enter amount</input>
                <li>Customer satisfaction</li>
                <input>Enter percentage</input>
                <li>On time delivery rate</li>
                <input>Enter Percentage</input>
                </ol></p>
              
            </div>
            <div class="card">
                <h3>Sales by region</h3>
                <p><ol type="1"><li>Asia</li>
                    <input>Enter amount in $</input>
                    <li>South America</li>
                    <input>Enter amount in $</input>
                    <li>North America</li>
                    <input>Enter amount in $</input>
                    <li>Europe</li>
                    <input>Enter amount in $</input>
                    </ol></p>
            </div>
            <div class="card">
                <h3>PRODUCT</h3>
                <p><ol type="1"><li>Vegetables</li>
                    <input>Enter amount in pieces and ton with specific name</input>
                    <li>Fruits</li>
                    <input>Enter amount in pieces and ton with specific name</input>
                    <li>Dairy</li>
                    <input>Enter amount in pieces and ton with specific name</input>
                    <li>Grains and cerens</li>
                    <input>Enter amount in ton</input>
                    </ol></p>
            </div>
            <div class="card">
              
              <h3>Wholesaler's Details</h3>
              <p><ol type="1"><li>Name</li>
                <input>Enter name</input>
                <li>ID</li>
                <input>Enter ID</input>
                <li>E-mail</li>
                <input>Enter E-mail</input>
                <li>Contact number</li>
                <input>Enter Contact number</input>
                </ol></p>
            </div>
          </div>
    
          
                </div>
              </div>
            </div>
          </section>
        </section>
      </div>
    </body>
    </html></span>