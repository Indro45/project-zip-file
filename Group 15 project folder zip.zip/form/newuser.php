<?php
    include('db.php');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content= "width=device-width, initial-scale=1">
    <title>Form Login and Register</title>
    <link rel="stylesheet" href="signup.css">
</head>
<body>    
    <h1>WELCOME NEW USER<br>
    Your Dashboard will be created by our developer as soon as possible</h1>
    <a href="login.php">Logout</a>
</body>
</html>     